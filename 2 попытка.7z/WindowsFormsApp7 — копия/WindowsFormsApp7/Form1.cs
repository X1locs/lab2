﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace WindowsFormsApp7
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            textBox1.Text = Properties.Settings.Default.first;
            textBox2.Text = Properties.Settings.Default.second;
            textBox3.Text = Properties.Settings.Default.result;
        }

       

        public class Logic
        {

            public static bool CheckWord(string word)
            {
                bool isWord = true;
                foreach (char ch in word)
                {
                    if (!Char.IsLetter(ch))
                    {
                        isWord = false;
                    }
                }
                return isWord;
            }

    public static string Compare(string first, string second)
            {
                string outMessage = " ";
                string str = "";
                //удаляем повторяющиеся буквы в первой строке
                for (int i = 0; i < first.Length - 1; i++)
                {
                    for (int j = i + 1; j < first.Length; j++)
                    {
                        if (first[i] == first[j])
                            first = first.Remove(j, 1);
                    }
                }

                //с помощью метода contains проверяем содержится ли первая строка во второй
                for (int i = 0; i < first.Length; i++)
                {
                    if (second.Contains(first[i]))

                        str += "да ";
                    else
                        str += "нет ";
                }
                outMessage = str;
                return outMessage;
            }
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            string first = textBox1.Text;
            string second = textBox2.Text;

            if (first == "" || second == "" || !(Logic.CheckWord(first) && Logic.CheckWord(second)))
            {
                MessageBox.Show("В поля можно вводить только буквы", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                string result = Logic.Compare(first, second);
                textBox3.Text = result.ToString();
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            textBox1.Text = "";
        }

        private void button3_Click(object sender, EventArgs e)
        {
            textBox2.Text = "";
        }

        private void button4_Click(object sender, EventArgs e)
        {
            textBox1.Text = "";
            textBox2.Text = "";
            textBox3.Text = "";
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            Properties.Settings.Default.first = textBox1.Text;
            Properties.Settings.Default.second = textBox2.Text;
            Properties.Settings.Default.result = textBox3.Text;

            Properties.Settings.Default.Save();
        }

        private void textBox1_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                textBox2.Focus();
            }
        }
    }
}
